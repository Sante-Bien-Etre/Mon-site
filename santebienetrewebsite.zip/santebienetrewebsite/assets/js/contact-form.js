// Validation du formulaire de contact
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Récupérer les valeurs
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();
            
            // Validation simple
            let isValid = true;
            
            if (name === '') {
                alert('Veuillez entrer votre nom');
                isValid = false;
            }
            
            if (email === '') {
                alert('Veuillez entrer votre email');
                isValid = false;
            } else if (!isValidEmail(email)) {
                alert('Veuillez entrer un email valide');
                isValid = false;
            }
            
            if (message === '') {
                alert('Veuillez entrer votre message');
                isValid = false;
            }
            
            if (isValid) {
                // Ici, normalement vous enverriez les données à un serveur
                alert('Message envoyé avec succès !\n\nNom: ' + name + '\nEmail: ' + email + '\nMessage: ' + message);
                contactForm.reset();
            }
        });
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});